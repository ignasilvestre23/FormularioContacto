/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package contacto;

public class Contacto {

    private String nombre;
    private String apellido;
    private String dni;
    private String pasaporte;
    private String telefono;
    private String codigoPostal;
    private String domicilio;

    public Contacto() {}

    public String getNombre()      { return nombre; }
    public String getApellido()    { return apellido; }
    public String getDni()         { return dni; }
    public String getPasaporte()   { return pasaporte; }
    public String getTelefono()    { return telefono; }
    public String getCodigoPostal(){ return codigoPostal; }
    public String getDomicilio()   { return domicilio; }

    public void setNombre(String nombre)           { this.nombre = nombre; }
    public void setApellido(String apellido)       { this.apellido = apellido; }
    public void setDni(String dni)                 { this.dni = dni; }
    public void setPasaporte(String pasaporte)     { this.pasaporte = pasaporte; }
    public void setTelefono(String telefono)       { this.telefono = telefono; }
    public void setCodigoPostal(String codigoPostal){ this.codigoPostal = codigoPostal; }
    public void setDomicilio(String domicilio)     { this.domicilio = domicilio; }
}