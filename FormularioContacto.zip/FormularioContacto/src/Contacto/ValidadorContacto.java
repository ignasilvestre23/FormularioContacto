/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package contacto;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 *
 * @author WIN11
 */

public class ValidadorContacto {

    // Devuelve un mapa campo -> mensaje de error. Si está vacío, todo es válido.
    public Map<String, String> validar(Contacto c) {
        Map<String, String> errores = new LinkedHashMap<>();

        // Nombre
        if (c.getNombre() == null || c.getNombre().trim().isEmpty())
            errores.put("nombre", "El nombre no puede estar vacío.");

        // Apellido
        if (c.getApellido() == null || c.getApellido().trim().isEmpty())
            errores.put("apellido", "El apellido no puede estar vacío.");

        // DNI y Pasaporte: excluyentes, pero uno obligatorio
        boolean tieneDni       = c.getDni()       != null && !c.getDni().trim().isEmpty();
        boolean tienePasaporte = c.getPasaporte() != null && !c.getPasaporte().trim().isEmpty();

        if (tieneDni && tienePasaporte) {
            errores.put("dni",       "Solo DNI o Pasaporte, no ambos.");
            errores.put("pasaporte", "Solo DNI o Pasaporte, no ambos.");
        } else if (!tieneDni && !tienePasaporte) {
            errores.put("dni", "Debe ingresar DNI o Pasaporte.");
        } else if (tieneDni) {
            String dni = c.getDni().trim();
            if (dni.length() != 8) {
                errores.put("dni", "El DNI debe tener exactamente 8 dígitos.");
            } else {
                long num = Long.parseLong(dni);
                if (num < 10_000_000L || num > 60_000_000L)
                    errores.put("dni", "El DNI debe estar entre 10.000.000 y 60.000.000.");
            }
        } else {
            if (!c.getPasaporte().trim().matches("[A-Za-z][0-9]{8}"))
                errores.put("pasaporte", "Formato inválido. Ej: N39392288 (1 letra + 8 dígitos).");
        }

        // Teléfono
        if (c.getTelefono() == null || c.getTelefono().trim().isEmpty()) {
            errores.put("telefono", "El teléfono no puede estar vacío.");
        } else {
            String soloDigitos = c.getTelefono().replaceAll("[^0-9]", "");
            if (soloDigitos.length() <= 6)
                errores.put("telefono", "El teléfono debe tener más de 6 dígitos numéricos.");
        }

        // Código Postal
        if (c.getCodigoPostal() == null || c.getCodigoPostal().trim().isEmpty()) {
            errores.put("codigoPostal", "El código postal no puede estar vacío.");
        } else if (c.getCodigoPostal().trim().length() != 4) {
            errores.put("codigoPostal", "El código postal debe tener exactamente 4 dígitos.");
        }

        // Domicilio
        if (c.getDomicilio() == null || c.getDomicilio().trim().isEmpty())
            errores.put("domicilio", "El domicilio no puede estar vacío.");

        return errores;
    }
}