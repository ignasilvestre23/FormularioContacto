/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package contacto;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.util.Map;

public class FormularioContacto extends JFrame {

    private JTextField txtNombre;
    private JTextField txtApellido;
    private JTextField txtDni;
    private JTextField txtPasaporte;
    private JTextField txtTelefono;
    private JTextField txtCodigoPostal;
    private JTextField txtDomicilio;

    private JLabel lblErrorNombre;
    private JLabel lblErrorApellido;
    private JLabel lblErrorDni;
    private JLabel lblErrorPasaporte;
    private JLabel lblErrorTelefono;
    private JLabel lblErrorCodigoPostal;
    private JLabel lblErrorDomicilio;

    private final ValidadorContacto validador = new ValidadorContacto();

    public FormularioContacto() {
        initComponents();
    }

    private void initComponents() {
        setTitle("Carga de Contacto");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel panelPrincipal = new JPanel(new BorderLayout(10, 10));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        panelPrincipal.setBackground(Color.WHITE);

        JLabel lblTitulo = new JLabel("Carga de contacto", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 18));
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        panelPrincipal.add(lblTitulo, BorderLayout.NORTH);

        JPanel panelCampos = new JPanel(new GridBagLayout());
        panelCampos.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 5, 2, 5);
        gbc.anchor = GridBagConstraints.WEST;

        txtNombre = new JTextField(20);
        aplicarFiltroSoloLetras(txtNombre, 20);
        lblErrorNombre = crearLabelError();
        agregarCampo(panelCampos, gbc, 0, "Nombre:", txtNombre, "(máximo 20 caracteres)", lblErrorNombre);

        txtApellido = new JTextField(20);
        aplicarFiltroSoloLetras(txtApellido, 20);
        lblErrorApellido = crearLabelError();
        agregarCampo(panelCampos, gbc, 1, "Apellido:", txtApellido, "(máximo 20 caracteres)", lblErrorApellido);

        txtDni = new JTextField(10);
        aplicarFiltroSoloNumeros(txtDni, 8);
        lblErrorDni = crearLabelError();
        agregarCampo(panelCampos, gbc, 2, "DNI:", txtDni, "(8 dígitos, entre 10.000.000 y 60.000.000)", lblErrorDni);

        txtPasaporte = new JTextField(12);
        aplicarFiltroMaxLong(txtPasaporte, 9);
        lblErrorPasaporte = crearLabelError();
        agregarCampo(panelCampos, gbc, 3, "Pasaporte:", txtPasaporte, "(1 letra + 8 dígitos, ej: N39392288)", lblErrorPasaporte);

        txtTelefono = new JTextField(20);
        aplicarFiltroTelefono(txtTelefono);
        lblErrorTelefono = crearLabelError();
        agregarCampo(panelCampos, gbc, 4, "Teléfono:", txtTelefono, "(> 6 dígitos y +()- ej: +54 9 (261)-5-012345)", lblErrorTelefono);

        txtCodigoPostal = new JTextField(6);
        aplicarFiltroSoloNumeros(txtCodigoPostal, 4);
        lblErrorCodigoPostal = crearLabelError();
        agregarCampo(panelCampos, gbc, 5, "Código Postal:", txtCodigoPostal, "(4 dígitos numéricos)", lblErrorCodigoPostal);

        txtDomicilio = new JTextField(30);
        aplicarFiltroMaxLong(txtDomicilio, 50);
        lblErrorDomicilio = crearLabelError();
        agregarCampo(panelCampos, gbc, 6, "Domicilio:", txtDomicilio, "(máximo 50 caracteres)", lblErrorDomicilio);

        panelPrincipal.add(panelCampos, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        panelBotones.setBackground(Color.WHITE);

        JButton btnValidar = new JButton("Validar");
        JButton btnLimpiar = new JButton("Limpiar");
        JButton btnCerrar  = new JButton("Cerrar");

        Dimension dimBtn = new Dimension(100, 30);
        btnValidar.setPreferredSize(dimBtn);
        btnLimpiar.setPreferredSize(dimBtn);
        btnCerrar.setPreferredSize(dimBtn);

        btnValidar.addActionListener(e -> onValidar());
        btnLimpiar.addActionListener(e -> limpiarFormulario());
        btnCerrar.addActionListener(e -> System.exit(0));

        panelBotones.add(btnValidar);
        panelBotones.add(btnLimpiar);
        panelBotones.add(btnCerrar);

        panelPrincipal.add(panelBotones, BorderLayout.SOUTH);
        add(panelPrincipal);
        pack();
        setLocationRelativeTo(null);
    }

    // ── Botón Validar: arma el modelo y delega al validador ──────────────────

    private void onValidar() {
        limpiarErrores();

        Contacto c = new Contacto();
        c.setNombre(txtNombre.getText());
        c.setApellido(txtApellido.getText());
        c.setDni(txtDni.getText());
        c.setPasaporte(txtPasaporte.getText());
        c.setTelefono(txtTelefono.getText());
        c.setCodigoPostal(txtCodigoPostal.getText());
        c.setDomicilio(txtDomicilio.getText());

        Map<String, String> errores = validador.validar(c);

        if (errores.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "✔ Formulario validado correctamente.",
                    "Validación exitosa",
                    JOptionPane.INFORMATION_MESSAGE);
        } else {
            mostrarErrores(errores);
            pack();
        }
    }

    private void mostrarErrores(Map<String, String> errores) {
        if (errores.containsKey("nombre"))      lblErrorNombre.setText(errores.get("nombre"));
        if (errores.containsKey("apellido"))    lblErrorApellido.setText(errores.get("apellido"));
        if (errores.containsKey("dni"))         lblErrorDni.setText(errores.get("dni"));
        if (errores.containsKey("pasaporte"))   lblErrorPasaporte.setText(errores.get("pasaporte"));
        if (errores.containsKey("telefono"))    lblErrorTelefono.setText(errores.get("telefono"));
        if (errores.containsKey("codigoPostal"))lblErrorCodigoPostal.setText(errores.get("codigoPostal"));
        if (errores.containsKey("domicilio"))   lblErrorDomicilio.setText(errores.get("domicilio"));
    }

    // ── Helpers UI ────────────────────────────────────────────────────────────

    private JLabel crearLabelError() {
        JLabel lbl = new JLabel(" ");
        lbl.setForeground(Color.RED);
        lbl.setFont(new Font("Arial", Font.PLAIN, 11));
        return lbl;
    }

    private void agregarCampo(JPanel panel, GridBagConstraints gbc, int fila,
                               String etiqueta, JTextField campo, String hint, JLabel lblError) {
        int y = fila * 3;

        gbc.gridx = 0; gbc.gridy = y;
        gbc.gridwidth = 1; gbc.fill = GridBagConstraints.NONE;
        JLabel lbl = new JLabel(etiqueta);
        lbl.setFont(new Font("Arial", Font.PLAIN, 13));
        panel.add(lbl, gbc);

        gbc.gridx = 1; gbc.gridy = y;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        campo.setFont(new Font("Arial", Font.PLAIN, 13));
        panel.add(campo, gbc);

        gbc.gridx = 2; gbc.gridy = y;
        gbc.fill = GridBagConstraints.NONE;
        JLabel lblHint = new JLabel(hint);
        lblHint.setFont(new Font("Arial", Font.ITALIC, 11));
        lblHint.setForeground(Color.GRAY);
        panel.add(lblHint, gbc);

        gbc.gridx = 1; gbc.gridy = y + 1;
        gbc.gridwidth = 2;
        panel.add(lblError, gbc);
        gbc.gridwidth = 1;
    }

    // ── Filtros a nivel de carácter ───────────────────────────────────────────

    private void aplicarFiltroSoloLetras(JTextField campo, int maxLen) {
        ((AbstractDocument) campo.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr)
                    throws BadLocationException {
                String nuevo = string.replaceAll("[^a-zA-ZáéíóúÁÉÍÓÚüÜñÑ ]", "");
                if (fb.getDocument().getLength() + nuevo.length() <= maxLen)
                    super.insertString(fb, offset, nuevo, attr);
            }
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
                    throws BadLocationException {
                String nuevo = text.replaceAll("[^a-zA-ZáéíóúÁÉÍÓÚüÜñÑ ]", "");
                if (fb.getDocument().getLength() - length + nuevo.length() <= maxLen)
                    super.replace(fb, offset, length, nuevo, attrs);
            }
        });
    }

    private void aplicarFiltroSoloNumeros(JTextField campo, int maxLen) {
        ((AbstractDocument) campo.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr)
                    throws BadLocationException {
                String nuevo = string.replaceAll("[^0-9]", "");
                if (fb.getDocument().getLength() + nuevo.length() <= maxLen)
                    super.insertString(fb, offset, nuevo, attr);
            }
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
                    throws BadLocationException {
                String nuevo = text.replaceAll("[^0-9]", "");
                if (fb.getDocument().getLength() - length + nuevo.length() <= maxLen)
                    super.replace(fb, offset, length, nuevo, attrs);
            }
        });
    }

    private void aplicarFiltroTelefono(JTextField campo) {
        ((AbstractDocument) campo.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr)
                    throws BadLocationException {
                String nuevo = string.replaceAll("[^0-9+()\\- ]", "");
                super.insertString(fb, offset, nuevo, attr);
            }
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
                    throws BadLocationException {
                String nuevo = text.replaceAll("[^0-9+()\\- ]", "");
                super.replace(fb, offset, length, nuevo, attrs);
            }
        });
    }

    private void aplicarFiltroMaxLong(JTextField campo, int maxLen) {
        ((AbstractDocument) campo.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr)
                    throws BadLocationException {
                if (fb.getDocument().getLength() + string.length() <= maxLen)
                    super.insertString(fb, offset, string, attr);
            }
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
                    throws BadLocationException {
                if (fb.getDocument().getLength() - length + text.length() <= maxLen)
                    super.replace(fb, offset, length, text, attrs);
            }
        });
    }

    private void limpiarErrores() {
        lblErrorNombre.setText(" ");
        lblErrorApellido.setText(" ");
        lblErrorDni.setText(" ");
        lblErrorPasaporte.setText(" ");
        lblErrorTelefono.setText(" ");
        lblErrorCodigoPostal.setText(" ");
        lblErrorDomicilio.setText(" ");
    }

    private void limpiarFormulario() {
        txtNombre.setText("");
        txtApellido.setText("");
        txtDni.setText("");
        txtPasaporte.setText("");
        txtTelefono.setText("");
        txtCodigoPostal.setText("");
        txtDomicilio.setText("");
        limpiarErrores();
    }
}